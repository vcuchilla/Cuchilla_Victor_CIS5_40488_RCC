/* 
  File:   main.cpp
  Author: Victor, Cuchilla
  Created on January 10, 2017, 5:00 PM
  Purpose:  This Program displays the programmers personal Information
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    //Output values
    cout<<"  Name: Victor Cuchilla\n"//Display Full Name
          "  Address: Riverside, California 92505\n"//Display Address
          "  Phone Number: 951-660-9909\n"//Display Phone Number
          "  College Major: Mechanical Engineering\n"; //Display College Major
    //Exit stage right!
    return 0;
}
