/* 
  File:   main.cpp
  Author: Victor, Cuchilla
  Created on January 10, 2017, 5:45 PM
  Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    //Output values
    cout<<"This Program Displays a Diamond Pattern from the * character\n";
    cout<<"\n";
    cout<<"                           *     \n"
          "                          ***    \n"
          "                         *****   \n"
          "                        *******  \n"
          "                         *****   \n"
          "                          ***    \n"
          "                           *     \n";
    //Exit stage right!
    return 0;
}